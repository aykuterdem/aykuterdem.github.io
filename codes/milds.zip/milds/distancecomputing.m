%this file is adapted from 'milesfeaturemapping.m' in MILES. 



% Input:
%       C-- A d x n matrix where d is the dimension of instance
%           feature vectors, n is the number of instances used 
%           in constructing the instance-based feature mapping.
%           It can be the instances in all the training bags.
%       D-- A 1 x m cell array containing bags. Each cell is a bag, 
%           which is a matrix. Each column of the matrix is an
%           instance.

% Output:
%       K-- A m x n matrix. Each row corresponds to a bag.

function K = distancecomputing(C, D)
[d,n] = size(C);
m = length(D);
K = zeros(m,n);
for i = 1:m
    junk = zeros(size(D{i},2),n);
    for j = 1:size(D{i},2)
        for k = 1:n
            junk(j,k) = norm(D{i}(:,j) - C(:,k));
        end
        K(i,:) = min(junk,[],1);
    end
end
