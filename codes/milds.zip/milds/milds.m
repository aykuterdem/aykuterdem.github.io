% This code is based on the paper
% 
% Multiple-Instance Learning with Instance Selection via Dominant Sets
% Aykut Erdem and Erkut Erdem 
% 1st Int. Workshop on Similarity-Based Pattern Analysis and Recognition (SIMBAD 2011)
% 
% The script uses some helper functions provided by W-J Li and D-Y Yeung
% for their MILD: Multiple-instance learning via disambiguation algorithm 
%
% -- can be downloaded from: http://www.cs.sjtu.edu.cn/~liwujun/code/mild.rar

clear
clc;

load('Musk1.mat');                          % [AllBags label]: Bags and their labels
load('randperms.mat');                      % [RandomPermutations]: 10 random permutations of bag indices

nFeats = size(AllBags{1},1);

nRuns = 10;                                 % 10 runs
svmC  = 16;
scaleG = 0.7;

AllAccuracy = zeros(1,1);
for r=1:nRuns
    AllIndex = RandomPermutations(r,:);

    AllAccuracy_bag = zeros(1,10);         
    for k=1:10                              % 10 times 10 fold
        BagNum = length(AllIndex);  
        BagsPerFold = round(BagNum*0.1);
        NumOfAllPosBags = sum(label==1); 
        OriginalTestIndex = AllIndex (BagsPerFold*(k-1)+1:BagsPerFold*k); 
        testIndex = sort(OriginalTestIndex);     

        VecTestPosIndices = testIndex(find(testIndex <= NumOfAllPosBags));
        VecTestNegIndices = setdiff(testIndex,VecTestPosIndices);
        VecTrainPosIndices = setdiff([1:NumOfAllPosBags], VecTestPosIndices);
        VecTrainNegIndices = setdiff([NumOfAllPosBags+1:BagNum], VecTestNegIndices);

        NumOfNegTrainingBags = size(VecTrainNegIndices,2);
        
        [traindata testdata label_train label_test]=selectdata(AllBags, label,...
                                                               VecTrainPosIndices,VecTrainNegIndices,...
                                                               VecTestPosIndices,VecTestNegIndices);  

        TrainSampleMean = mean(mean(squareform(pdist(cell2mat(traindata,nFeats)'))));                                                 

        sigma = scaleG*TrainSampleMean;
        
        NumOfPosTrainingBags = length(VecTrainPosIndices);
        NumOfPosTestingBags  = length(VecTestPosIndices);
        TrainPosData         = traindata(find(label_train==1));
        TrainNegData         = traindata(find(label_train==-1));

        % Compute pairwise affinities between all the instances in the
        % training negative bags
        dataTrainNeg = cell2mat(TrainNegData,nFeats)';
        AffinityTrainNeg = exp(-squareform(pdist(dataTrainNeg)).^2/(2*sigma^2));

        % Cluster instances in the negative training bags
        [NegClusters X NegPrototypeIndices payoffs nNegCluster] = clusterDS(AffinityTrainNeg, 'MaxClust', NumOfNegTrainingBags);

        % Form negative instance prototypes (Eqn. 5)
        VecNegPrototypes = zeros(nNegCluster,nFeats);
        sizeNegClusters  = zeros(nNegCluster,1);
        for i=1:nNegCluster
            VecNegPrototypes(i,:) = dataTrainNeg(NegPrototypeIndices(i),:);
            sizeNegClusters(i)    = sum(NegClusters==i);
        end

        % Form positive instance prototypes (Eqn. 6)
        VecPosPrototypes    = zeros(NumOfPosTrainingBags,nFeats);  
        PosPrototypeIndices = zeros(NumOfPosTrainingBags,1);  
        nPtsCum = 0;
        for i=1:NumOfPosTrainingBags
            posbagdata = TrainPosData{i}';
            nPts       = size(posbagdata,1);

            simToNegCluster = zeros(nPts,nNegCluster);
            for j=1:nNegCluster
                D = pdist2(posbagdata,dataTrainNeg(NegClusters==j,:));
                A = exp(-D.^2/(2*sigma^2));

                x = X(j,:);
                x = x(x>0)';

                simToNegCluster(:,j) = A*x;
            end

            [minSim best] = min(simToNegCluster*sizeNegClusters/sum(sizeNegClusters));

            PosPrototypeIndices(i) = nPtsCum+best;
            VecPosPrototypes(i,:)  = posbagdata(best,:);
            nPtsCum = nPtsCum+nPts;
        end    

        % Store descripts of the selected prototypes
        C = [VecPosPrototypes; VecNegPrototypes]';
    
        % Linear SVM training
        Ktrain = distancecomputing(C, traindata);
        Ktrain = exp(-Ktrain.^2/(2*sigma^2));
        
        Ktest = distancecomputing(C, testdata);
        Ktest = exp(-Ktest.^2/(2*sigma^2));
        
        parameter = sprintf('-t 0 -c %f -b 1 -q',svmC);
        
        model = svmtrain(label_train', Ktrain, parameter)
        [predict_label, accuracy2, dec_values2] = svmpredict(label_test', Ktest, model, '-b 1');
        AllAccuracy_bag(k) = accuracy2(1)/100;
    end

    AllAccuracy(r) = mean(AllAccuracy_bag);
end

MILDS= mean(AllAccuracy);
stdev = std(AllAccuracy);
fprintf(1,'Mean Accuracy: %.1f\n',100*MILDS);
fprintf(1,'Standard Deviation: %.1f\n',100*stdev);
