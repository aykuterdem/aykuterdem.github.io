function [traindata testdata label_train label_test]=selectdata(data, label, VecTrainPosIndices,VecTrainNegIndices,VecTestPosIndices,VecTestNegIndices)


traindata =[];
testdata = [];
label_train = [];
label_test = [];


traindata = [data(VecTrainPosIndices) data(VecTrainNegIndices)];
testdata = [data(VecTestPosIndices) data(VecTestNegIndices)];
label_train(1:length(VecTrainPosIndices)) = 1;
label_train(length(VecTrainPosIndices)+1:length(VecTrainPosIndices)+length(VecTrainNegIndices)) = -1;
label_test(1:length(VecTestPosIndices)) = 1;
label_test(length(VecTestPosIndices)+1:length(VecTestPosIndices)+length(VecTestNegIndices)) = -1;





